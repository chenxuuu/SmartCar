#ifndef _VCAN_IMG2SD_H_
#define _VCAN_IMG2SD_H_

extern void img_sd_init(void);
extern void img_sd_save(uint8 * imgaddr,uint32 size);
extern void img_sd_exit(void);






#endif //_VCAN_IMG2SD_H_
