#ifndef __SWJ_H__
#define __SWJ_H__

void swj_lz(uint8 (*ab)[136],uint8 c);

#endif