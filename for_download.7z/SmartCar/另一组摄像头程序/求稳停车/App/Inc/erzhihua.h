#ifndef __ERZHIHUA_H__
#define __ERZHIHUA_H__

void erzhihua_x(uint8 (*ab)[136],uint8 ms);

#endif