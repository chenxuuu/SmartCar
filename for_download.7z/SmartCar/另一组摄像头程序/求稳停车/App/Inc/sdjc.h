#ifndef __SDJC_H__
#define __SDJC_H__

uint8 sdjc_zd(uint8 (*ab)[136],uint8 (*bc)[10]);
uint8 sdjc_mx(uint8 (*ab)[136],uint8 (*bc)[10]);
uint8 sdjc_sz(uint8 (*ab)[136],uint8 (*bc)[10]);
uint8 sdjc_wd(uint8 (*ab)[136],uint8 (*bc)[10]);
uint8 sdjc_tc(uint8 (*ab)[136]);    //ͣ����
void sdjc_za(uint8 (*ab)[136],uint8 (*bc)[10]);    //�ϰ�

#endif